from django.shortcuts import render
from songs.models import Movie,Audio,Video
# search list imports
from django.contrib import messages
from django.db.models import Q
#HttpResponseRedirect
from django.http import HttpResponseRedirect, HttpResponse
#forms
from songs.forms import ContactForm

from django.conf import settings
#mails
from django.core.mail import send_mail

# Create your views here.

def index(request):
    return render(request, 'index.html')

def aboutus(request):
    return render(request, 'aboutus.html')

def contactus(request):
    form= ContactForm(request.POST or None)
    if form.is_valid():
        name=request.POST.get('contact_name')
        email=request.POST.get('contact_email')
        content=request.POST.get('content')
        #sending email
        subject='Enquiry Mail Musicality.com'
        message=content
        #+"We will revert you soon! Thank you and Visit Again."
        from_email = settings.EMAIL_HOST_USER
        to_email = email
        to_list= [from_email,to_email]
        send_mail(subject, message, from_email, to_list, fail_silently= False)
        return HttpResponseRedirect('thankyou')

    return render(request, 'contactus.html',{'form':form})

def thankyou(request):
    res = HttpResponse()
    res.write("<h1> Thanks for contacting us !</h1>")
    res.write("<h2> We have sent you a mail, please check")
    return res

def movies(request):
    qs=Movie.objects.all()
    return render(request,"movies.html",{'mlst':qs})

def movie_details(request,x):
    m=Movie.objects.get(id=x)
    lst1=Audio.objects.all()
    lst2=Video.objects.all()
    return render(request,'movie_details.html',{'m':m,'alist':lst1,'vlist':lst2})

def songs(request):
    lst=Audio.objects.all()
    return render(request,'songs.html',{'alist':lst})

def videos(request):
    lst=Video.objects.all()
    return render(request,'videos.html',{'vlist':lst})

def search_list(request):
    q=request.GET.get('query')
    if q:
        match1= Movie.objects.filter(Q(title__icontains = q) | Q(director__icontains=q))
        match2= Audio.objects.filter(Q(title__icontains = q))
        match3= Video.objects.filter(Q(title__icontains = q))
        if match1 or match2 or match3:
            return render(request,'search_list.html',{'m1':match1,'m2':match2,'m3':match3})
        else:
            messages.error(request,'No Result Found')
            return HttpResponseRedirect('/index')
    else:
        return HttpResponseRedirect('/index')

    return render(request, 'search_list.html')


