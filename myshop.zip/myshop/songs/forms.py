from django import forms

class ContactForm(forms.Form):
    contact_name= forms.CharField(label= 'Enter Your Name: ', required=True)
    contact_email=forms.CharField(label= 'Enter Your Email Id: ',required=True)
    content=forms.CharField(label='Type Your Message ',required=True, widget=forms.Textarea)

